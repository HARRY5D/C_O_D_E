# Core module for the Code Complexity Analyzer
