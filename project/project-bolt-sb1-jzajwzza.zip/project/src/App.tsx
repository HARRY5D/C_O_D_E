import { BrowserRouter as Router, Routes, Route, Link, useNavigate, useLocation } from 'react-router-dom';
import { Search, Star, ThumbsUp, Filter, ExternalLink, LogOut, Plus, Home } from 'lucide-react';
import { Toaster } from 'react-hot-toast';
import { supabase } from './lib/supabase';
import { Auth } from './components/Auth';
import { ResetPassword } from './components/ResetPassword';
import { AddTool } from './components/AddTool';
import { FeaturedTools } from './components/FeaturedTools';
import { categories } from './lib/constants';
import { useState, useEffect, Suspense } from 'react';
import { ThemeToggle } from './lib/ThemeContext';

// Home button component that only shows on non-home pages
function HomeButton() {
  const location = useLocation();
  const navigate = useNavigate();

  if (location.pathname === '/') return null;

  return (
    <button
      onClick={() => navigate('/')}
      className="fixed bottom-8 right-8 bg-purple-600 dark:bg-purple-500 text-white p-4 rounded-full shadow-lg hover:bg-purple-700 dark:hover:bg-purple-600 transition-colors duration-200 z-50"
      aria-label="Back to Home"
    >
      <Home size={24} />
    </button>
  );
}

function App() {
  const [user, setUser] = useState(null);
  const [tools, setTools] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const initializeAuth = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        setUser(session?.user ?? null);
        setLoading(false);
      } catch (err) {
        console.error('Auth initialization error:', err);
        setError(null);
        setLoading(false);
      }
    };

    initializeAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    fetchTools();
  }, [selectedCategory, searchQuery]);

  const fetchTools = async () => {
    try {
      setLoading(true);
      setError(null);
      
      let query = supabase
        .from('tools')
        .select(`
          *,
          profiles:user_id(username),
          votes(rating)
        `)
        .order('created_at', { ascending: false });

      if (selectedCategory !== 'All') {
        query = query.eq('category', selectedCategory);
      }

      if (searchQuery) {
        query = query.or(`name.ilike.%${searchQuery}%,description.ilike.%${searchQuery}%`);
      }

      const { data, error: fetchError } = await query;
      
      if (fetchError) throw fetchError;

      const toolsWithStats = data?.map(tool => ({
        ...tool,
        username: tool.profiles?.username,
        rating: tool.votes?.length > 0 
          ? tool.votes.reduce((acc, vote) => acc + vote.rating, 0) / tool.votes.length 
          : 0,
        votes: tool.votes?.length || 0
      })) || [];

      setTools(toolsWithStats);
    } catch (err) {
      console.error('Error fetching tools:', err);
      setError('Unable to load tools. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const handleVote = async (toolId, rating) => {
    try {
      if (!user) throw new Error('Please sign in to vote');

      const { error: voteError } = await supabase
        .from('votes')
        .upsert({
          tool_id: toolId,
          user_id: user.id,
          rating
        });

      if (voteError) throw voteError;

      await fetchTools();
    } catch (err) {
      console.error('Error voting:', err);
      setError(err.message);
    }
  };

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
    } catch (err) {
      console.error('Sign out error:', err);
    }
  };

  return (
    <Router>
      <div className="min-h-screen bg-gray-50 dark:bg-dark-bg text-gray-900 dark:text-gray-100 transition-colors duration-200">
        <Toaster position="top-right" />
        
        {/* Theme Toggle Bar */}
        <div className="bg-white dark:bg-dark-card border-b border-gray-200 dark:border-dark-border">
          <div className="container mx-auto px-4 py-2 flex justify-end">
            <ThemeToggle />
          </div>
        </div>
        
        {/* Header */}
        <header className="bg-gradient-to-r from-purple-600 to-indigo-600 dark:from-purple-800 dark:to-indigo-800 text-white">
          <div className="container mx-auto px-4 py-4">
            <div className="flex justify-between items-center mb-6">
              <Link to="/" className="text-2xl font-bold">Freelancer Tools Directory</Link>
              <div className="flex items-center space-x-4">
                {user ? (
                  <>
                    <Link
                      to="/submit"
                      className="flex items-center px-4 py-2 bg-white dark:bg-dark-card text-purple-600 dark:text-purple-400 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-border"
                    >
                      <Plus size={20} className="mr-2" />
                      Submit Tool
                    </Link>
                    <button
                      onClick={handleSignOut}
                      className="flex items-center px-4 py-2 bg-purple-700 dark:bg-purple-900 text-white rounded-lg hover:bg-purple-800 dark:hover:bg-purple-800"
                    >
                      <LogOut size={20} className="mr-2" />
                      Sign Out
                    </button>
                  </>
                ) : (
                  <Link
                    to="/auth"
                    className="px-4 py-2 bg-white dark:bg-dark-card text-purple-600 dark:text-purple-400 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-border"
                  >
                    Sign In
                  </Link>
                )}
              </div>
            </div>

            {/* Search and Categories in Header */}
            <div className="flex flex-col space-y-4 md:flex-row md:space-y-0 md:space-x-4 items-center">
              <div className="w-full md:w-96 relative">
                <Search className="absolute left-4 top-3.5 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder="Search for tools..."
                  className="w-full pl-12 pr-4 py-3 rounded-lg bg-white dark:bg-dark-card text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-purple-300 dark:focus:ring-purple-500"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                <button
                  onClick={() => setSelectedCategory('All')}
                  className={`px-4 py-2 rounded-full transition-colors duration-200 ${
                    selectedCategory === 'All'
                      ? 'bg-white dark:bg-dark-card text-purple-600 dark:text-purple-400'
                      : 'bg-purple-700 dark:bg-purple-900 text-white hover:bg-purple-800 dark:hover:bg-purple-800'
                  }`}
                >
                  All
                </button>
                {categories.map(category => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`px-4 py-2 rounded-full transition-colors duration-200 ${
                      selectedCategory === category
                        ? 'bg-white dark:bg-dark-card text-purple-600 dark:text-purple-400'
                        : 'bg-purple-700 dark:bg-purple-900 text-white hover:bg-purple-800 dark:hover:bg-purple-800'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </header>

        <Suspense fallback={
          <div className="flex items-center justify-center min-h-screen">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-600"></div>
          </div>
        }>
          <Routes>
            <Route path="/auth" element={
              <div className="container mx-auto px-4 py-12">
                <Auth />
              </div>
            } />
            
            <Route path="/auth/reset-password" element={
              <div className="container mx-auto px-4 py-12">
                <ResetPassword />
              </div>
            } />
            
            <Route path="/submit" element={
              <div className="container mx-auto px-4 py-12">
                {user ? <AddTool onToolAdded={fetchTools} /> : <Auth />}
              </div>
            } />
            
            <Route path="/" element={
              <main className="container mx-auto px-4 py-12">
                {error ? (
                  <div className="text-center py-12">
                    <p className="text-red-600 text-lg mb-4">{error}</p>
                    <button 
                      onClick={() => {
                        setError(null);
                        fetchTools();
                      }}
                      className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
                    >
                      Try Again
                    </button>
                  </div>
                ) : (
                  <>
                    <FeaturedTools 
                      tools={tools}
                      category={selectedCategory}
                      user={user}
                      onVote={handleVote}
                    />

                    {/* Tools Grid */}
                    {loading ? (
                      <div className="flex items-center justify-center py-12">
                        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-600"></div>
                      </div>
                    ) : tools.length === 0 && !loading ? (
                      <div className="text-center py-12">
                        <p className="text-gray-600 text-lg">
                          No user-submitted tools found. Try adjusting your search or category filter.
                        </p>
                      </div>
                    ) : null}
                  </>
                )}
              </main>
            } />
          </Routes>
        </Suspense>

        {/* Home Button */}
        <HomeButton />

        {/* Footer */}
        <footer className="bg-gray-800 dark:bg-dark-card text-white py-8">
          <div className="container mx-auto px-4 text-center">
            <p>© 2024 Freelancer Tools Directory. All tools are rated by the community.</p>
          </div>
        </footer>
      </div>
    </Router>
  );
}

export default App;